#!/bin/sh
rofi -show p -modi p:./off.sh -theme ./powermenu_theme.rasi
